//
//  SoundATests.swift
//  SoundATests
//
//  Created by Noura Alrowais on 21/06/1446 AH.
//

import Testing
@testable import SoundA

struct SoundATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
