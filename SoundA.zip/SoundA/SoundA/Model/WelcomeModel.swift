//
//  WelcomeModel.swift
//  SoundA
//
//  Created by Noura Alrowais on 21/06/1446 AH.
//

import SwiftUI

struct WelcomeModel {
    let title: String
    let subtitle: String
    let overlayText: String
    let imageName: String
}
