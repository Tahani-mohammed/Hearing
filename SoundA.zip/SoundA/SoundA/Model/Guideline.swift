//
//  Guideline.swift
//  SoundA
//
//  Created by Noura Alrowais on 21/06/1446 AH.
//

import SwiftUI

struct Guideline {
    let id = UUID()
    let color: Color
    let description: String
}
