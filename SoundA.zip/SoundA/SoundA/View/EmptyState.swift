//
//  EmptyState.swift
//  SoundA
//
//  Created by Noura Alrowais on 21/06/1446 AH.
//

import SwiftUI




struct EmptyState: View {
    @State private var showingSheet = false
    /// Indicates whether to display the setup workflow.
    @State var showSetup = true
    /// A configuration for managing the characteristics of a sound classification task.
    @State var appConfig = AppConfiguration()
    /// The runtime state that contains information about the strength of the detected sounds.
    @StateObject var appState = AppState()

    var body: some View {
        NavigationView{
            VStack{
                Text("This is an empty state")
                    .font(.title)
                Text("Click below button to start your journay")
                    .foregroundColor(Color.blue)
                Button(action: {
                    
                    showingSheet.toggle() // Show the sheet for new entry
                }) {
                    Image(systemName: "bell.badge.waveform.fill")  .resizable()
                        .frame(width: 30, height: 30)
                }
                
            }
        }.sheet(isPresented: $showingSheet){
            SetupMonitoredSoundsView(
              querySoundOptions: { return try AppConfiguration.listAllValidSoundIdentifiers() },
              selectedSounds: $appConfig.monitoredSounds,
              doneAction: {
                showSetup = false
                appState.restartDetection(config: appConfig)
              })
        }
                
                
            }
        }
        
    
    #Preview {
        EmptyState()
    }
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let rgbValue = UInt32(hex, radix: 16)
        let r = Double((rgbValue! & 0xFF0000) >> 16) / 255
        let g = Double((rgbValue! & 0x00FF00) >> 8) / 255
        let b = Double(rgbValue! & 0x0000FF) / 255
        self.init(red: r, green: g, blue: b)
    }
}
