//
//  GuidingViewModel.swift
//  SoundA
//
//  Created by Noura Alrowais on 21/06/1446 AH.
//

import SwiftUI

class GuidingViewModel: ObservableObject {
    @Published var navigateToContentView = false // State to trigger navigation
    @Published var isSoundDetected = false  // State to be passed to ARView
    
    let guidelines = [
        ("RED", "RED: INDICATES AN EMERGENCY THAT \nREQUIRES IMMEDIATE ATTENTION.", Color.red),
        ("YELLOW", "YELLOW: REPRESENTS A WARNING OR NON-URGENT ALERT.", Color.yellow),
        ("GREEN", "GREEN: EVERYTHING IS SAFE.", Color.green),
        ("BLUE", "BLUE: GENERAL NOTIFICATION FOR \nINFORMATION.", Color.blue)
    ]

    // Function to trigger ARView navigation
    func startContentView() {
        navigateToContentView = true
    }
}
