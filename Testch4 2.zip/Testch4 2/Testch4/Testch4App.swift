//
//  Testch4App.swift
//  Testch4
//
//  Created by Abeer on 14/06/1446 AH.
//

import SwiftUI

@main
struct Testch4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
