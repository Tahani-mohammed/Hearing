


import SwiftUI
import ARKit
import AVFoundation

struct ContentView: View {
    @State private var isSoundDetected = false // متغير حالة الصوت
    @State private var showAlert = false       // متغير للتحكم في ظهور التنبيه
    @State private var detectedSoundName: String? = nil // لتخزين اسم الصوت المتعرف عليه
    
    var body: some View {
        ZStack {
            SoundDetectionARView(isSoundDetected: $isSoundDetected, detectedSoundName: $detectedSoundName)
            
            // عرض التنبيه عند اكتشاف الصوت
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Sound Detected"), message: Text("Detected sound: \(detectedSoundName ?? "Unknown")"), dismissButton: .default(Text("OK")))
            }
        }
        .onChange(of: isSoundDetected) { newValue in // استخدام onChange بالشكل الصحيح
            if newValue {
                // عند اكتشاف الصوت، عرض التنبيه
                showAlert = true
                
                // إعادة ضبط حالة الصوت بعد 1.5 ثانية
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    isSoundDetected = false
                }
            }
        }
    }
}

struct SoundDetectionARView: UIViewRepresentable {
    @Binding var isSoundDetected: Bool
    @Binding var detectedSoundName: String? // تم إضافة هذا المتغير
    
    let audioEngine = AVAudioEngine()
    
    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView()
        arView.automaticallyUpdatesLighting = true
        arView.showsStatistics = true
        
        startAudioRecognition()
        
        return arView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: Context) {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        uiView.session.run(configuration)
    }
    
    func startAudioRecognition() {
        let inputNode = audioEngine.inputNode
        let audioFormat = inputNode.outputFormat(forBus: 0)
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: audioFormat) { (buffer, time) in
            self.analyzeAudio(buffer: buffer)
        }
        
        do {
            audioEngine.prepare()
            try audioEngine.start()
            print("Audio engine started!")
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }
    
    func analyzeAudio(buffer: AVAudioPCMBuffer) {
        let channelData = buffer.floatChannelData?[0]
        let channelDataArray = Array(UnsafeBufferPointer(start: channelData, count: Int(buffer.frameLength)))
        
        let rms = sqrt(channelDataArray.map { $0 * $0 }.reduce(0, +) / Float(channelDataArray.count))
        
        DispatchQueue.main.async {
            if rms > 0.09 { // عتبة التعرف على الصوت
                print("Detected sound with RMS: \(rms)")
                self.isSoundDetected = true
                
                // تعيين اسم الصوت المتعرف عليه (مثال: "Voice 1")
                self.detectedSoundName = "Voice 1" // استبدل هذا بالقيمة الفعلية التي تحصل عليها من ML
                
                // إعادة ضبط الحالة بعد نصف ثانية
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.isSoundDetected = false
                }
            }
        }
    }
}
