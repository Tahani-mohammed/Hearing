//
//  ViewController.swift
//  test9
//
//  Created by Noura Alrowais on 11/06/1446 AH.
//

import UIKit
import ARKit
import SceneKit
import AVFoundation

class ViewController: UIViewController, ARSCNViewDelegate, AVAudioRecorderDelegate {

    private var sceneView: ARSCNView!
    private var audioRecorder: AVAudioRecorder?

    override func viewDidLoad() {
        super.viewDidLoad()

        // إعداد واجهة ARSCNView
        sceneView = ARSCNView(frame: view.frame)
        sceneView.delegate = self
        sceneView.showsStatistics = true
        sceneView.scene = SCNScene()
        view.addSubview(sceneView)

        // بدء جلسة AR
        startARSession()

        // بدء تسجيل الصوت لاكتشاف مصدر الصوت
        setupAudioRecorder()
    }

    private func startARSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical]
        sceneView.session.run(configuration)
    }

    private func setupAudioRecorder() {
        let audioSession = AVAudioSession.sharedInstance()

        do {
            try audioSession.setCategory(.record, mode: .default, options: .duckOthers)
            try audioSession.setActive(true)

            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatAppleLossless),
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]

            audioRecorder = try AVAudioRecorder(url: URL(fileURLWithPath: "/dev/null"), settings: settings)
            audioRecorder?.delegate = self
            audioRecorder?.isMeteringEnabled = true
            audioRecorder?.record()

            // بدء مراقبة مستويات الصوت
            Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(monitorAudioLevels), userInfo: nil, repeats: true)
        } catch {
            print("فشل إعداد تسجيل الصوت: \(error.localizedDescription)")
        }
    }

    @objc private func monitorAudioLevels() {
        audioRecorder?.updateMeters()
        guard let recorder = audioRecorder else { return }

        // التحقق من مستوى الصوت
        let averagePower = recorder.averagePower(forChannel: 0)
        if averagePower > -10.0 { // عتبة الصوت
            add3DObjectAtSoundSource()
        }
    }

    private func add3DObjectAtSoundSource() {
        guard let currentFrame = sceneView.session.currentFrame else { return }

        // إنشاء كائن ثلاثي الأبعاد (مثل كرة)
        let sphere = SCNSphere(radius: 0.05)
        sphere.firstMaterial?.diffuse.contents = UIColor.red
        let sphereNode = SCNNode(geometry: sphere)

        // وضع الكائن أمام الكاميرا بمسافة 0.5 متر
        var translation = matrix_identity_float4x4
        translation.columns.3.z = -0.5
        sphereNode.simdTransform = matrix_multiply(currentFrame.camera.transform, translation)

        // إضافة الكائن إلى المشهد
        sceneView.scene.rootNode.addChildNode(sphereNode)
    }

    // معالجة أخطاء جلسة AR
    func session(_ session: ARSession, didFailWithError error: Error) {
        print("فشلت الجلسة: \(error.localizedDescription)")
    }

    func sessionWasInterrupted(_ session: ARSession) {
        print("تمت مقاطعة الجلسة")
    }

    func sessionInterruptionEnded(_ session: ARSession) {
        print("انتهت مقاطعة الجلسة")
    }
}
