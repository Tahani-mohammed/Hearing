import SwiftUI
import AVFoundation
import ARKit

// MARK: - ContentView

struct ContentView: View {
    @State private var audioLevel: Float = 0.0
    @State private var soundDirection: String = "Unknown"
    @State private var audioManager: AudioManager?

    var body: some View {
        ARViewContainer(audioLevel: $audioLevel, soundDirection: $soundDirection)
            .edgesIgnoringSafeArea(.all)
            .onAppear {
                setupAudioManager()  // تهيئة AudioManager عند ظهور الواجهة
            }
    }

    private func setupAudioManager() {
        audioManager = AudioManager(audioLevel: $audioLevel, soundDirection: $soundDirection)
    }
}


// MARK: - ARViewContainer

struct ARViewContainer: UIViewRepresentable {
    @Binding var audioLevel: Float
    @Binding var soundDirection: String
    @State private var showAlert = false // حالة التنبيه
    @State private var alertMessage = "" // النص الذي سيظهر في التنبيه

    func makeUIView(context: Context) -> ARSCNView {
        let arView = ARSCNView()
        arView.automaticallyUpdatesLighting = true
        arView.showsStatistics = true
        startARSession(arView)
        return arView
    }

    func updateUIView(_ uiView: ARSCNView, context: Context) {
        // يمكن إضافة أي تحديثات هنا إذا لزم الأمر
    }

    private func startARSession(_ arView: ARSCNView) {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        arView.session.run(configuration)
    }

    private func showSoundAlert() {
        self.alertMessage = "Sound Detected at \(soundDirection)"
        self.showAlert = true
    }

    var body: some View {
        ZStack {
            ARViewContainer(audioLevel: $audioLevel, soundDirection: $soundDirection)
                .edgesIgnoringSafeArea(.all)
            
            if showAlert {
                Text(alertMessage)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black.opacity(0.7))
                    .cornerRadius(10)
                    .transition(.opacity)
                    .onAppear {
                        // إخفاء التنبيه بعد 3 ثواني
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                            withAnimation {
                                self.showAlert = false
                            }
                        }
                    }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .soundDetected)) { notification in
            if let direction = notification.object as? String {
                self.soundDirection = direction
                showSoundAlert() // عرض التنبيه عندما يتم اكتشاف الصوت
            }
        }
    }
}


// MARK: - AudioManager

class AudioManager: ObservableObject {
    private var audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode!
    @Binding var audioLevel: Float
    @Binding var soundDirection: String
    
    init(audioLevel: Binding<Float>, soundDirection: Binding<String>) {
        _audioLevel = audioLevel
        _soundDirection = soundDirection
        setupAudioEngine()
    }

    private func setupAudioEngine() {
        inputNode = audioEngine.inputNode
        let format = inputNode.inputFormat(forBus: 0)
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { (buffer, time) in
            let rms = self.calculateRMS(from: buffer)
            let normalizedPower = max(rms / 0.5, 0)
            
            DispatchQueue.main.async {
                self.audioLevel = normalizedPower
                print("Audio level: \(self.audioLevel)")
            }
            
            if normalizedPower > 0.2 {  // العتبة المحددة
                self.determineSoundDirection(normalizedPower)
            }
        }
        
        do {
            try audioEngine.start()
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }

    private func calculateRMS(from buffer: AVAudioPCMBuffer) -> Float {
        let channelData = buffer.floatChannelData?[0]
        let frameLength = Int(buffer.frameLength)
        
        var sumOfSquares: Float = 0.0
        for i in 0..<frameLength {
            let sample = channelData?[i] ?? 0.0
            sumOfSquares += sample * sample
        }
        
        return sqrt(sumOfSquares / Float(frameLength))
    }

    private func determineSoundDirection(_ normalizedPower: Float) {
        if normalizedPower > 0.2 && normalizedPower <= 0.4 {
            self.soundDirection = "Left"
        } else if normalizedPower > 0.4 && normalizedPower <= 0.6 {
            self.soundDirection = "Center"
        } else if normalizedPower > 0.6 {
            self.soundDirection = "Right"
        }
        
        // إرسال التنبيه عند اكتشاف الصوت
        DispatchQueue.main.async {
            self.sendSoundDirectionAlert()
        }
    }

    private func sendSoundDirectionAlert() {
        // إرسال التنبيه عبر NotificationCenter
        NotificationCenter.default.post(name: .soundDetected, object: soundDirection)
    }
}


// MARK: - Notification Name Extension

extension Notification.Name {
    static let soundDetected = Notification.Name("soundDetected")
}
