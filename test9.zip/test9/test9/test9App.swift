//
//  test9App.swift
//  test9
//
//  Created by Noura Alrowais on 11/06/1446 AH.
//

import SwiftUI

@main
struct test9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
