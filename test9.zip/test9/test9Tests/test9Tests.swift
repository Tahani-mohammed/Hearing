//
//  test9Tests.swift
//  test9Tests
//
//  Created by Noura Alrowais on 11/06/1446 AH.
//

import Testing
@testable import test9

struct test9Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
